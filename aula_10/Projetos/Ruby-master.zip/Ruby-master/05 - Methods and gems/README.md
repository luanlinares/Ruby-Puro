To execute 002_cpf.rb, you'll need to run
```
bundle
ruby 002_cpf.rb
```

If you dont have bundle installed, run
```
gem install bundle
```

