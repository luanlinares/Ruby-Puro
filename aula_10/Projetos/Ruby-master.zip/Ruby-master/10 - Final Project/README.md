Run:
```
bundle
```
Then:
```
Ruby app.rb
```
Get the API key [here](https://translate.yandex.com/developers/keys).
