print "Digite o primeiro número: "
num1 = gets.chomp.to_i

print "Digite o segundo número: "
num2 = gets.chomp.to_i

p "A soma dos números é: #{num1 + num2}"
p "A subtração dos números é: #{num1 - num2}"
p "A multiplicação dos números é: #{num1 * num2}"
p "A divisão dos números é #{num1 / num2}"