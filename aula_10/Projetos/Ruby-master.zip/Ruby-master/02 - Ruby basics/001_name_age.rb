print "Digite seu nome: "
var1 = gets.chomp

print "Digite sua idade: "
var2 = gets.chomp

p "Seu nome é #{var1}, e você tem #{var2} anos."