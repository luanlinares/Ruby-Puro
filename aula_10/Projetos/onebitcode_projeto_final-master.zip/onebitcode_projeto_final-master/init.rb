require 'rest-client'
require 'json'

class Traduzir
  def initialize
    @key = "trnsl.1.1.20190415T135730Z.6e728903769d1236.e3ae7e8e5e59ede7f70eba07d19478ed201a2759"
    @url_listas = "https://translate.yandex.net/api/v1.5/tr.json/getLangs"
    @url_detecta = "https://translate.yandex.net/api/v1.5/tr.json/detect"
    @url_consulta = "https://translate.yandex.net/api/v1.5/tr.json/translate"

    print "Digite o texto para tradução: "
    texto = gets.chomp
    @texto = texto
    @idioma_detectado = detectar
    puts "Detectamos que o texto escrito é: #{@idioma_detectado}"
    print "Está Correto? (s/n): "
    selecao = gets.chomp
    case selecao.downcase
    when "s" #SE O IDIOMA DETECTADO ESTÁ CORRETO
      puts "SELECIONE O IDIOMA DE TRADUÇÃO PELO CÓDIGO ABAIXO:"
      puts "Carregando..."
      sleep(3)
      listar_idioma
      print "Digite o código do idioma para tradução: "
      cod_idioma_traducao = gets.chomp
      puts "Traduzindo... Texto: '#{@texto}' de '#{@idioma_detectado}' para '#{cod_idioma_traducao}'"
      sleep(3)
      puts "Tradução: "
      resultado = consulta(@idioma_detectado, cod_idioma_traducao)
      puts resultado
      gravar(@texto, resultado)
    when "n" # SE O IDIOMA DETECTADO NÃO ESTÁ CORRETO
      puts "SELECIONE SEU IDIOMA PELO CÓDIGO ABAIXO:"
      puts "Carregando..."
      sleep(3)
      listar_idioma
      print "Digite o código correpondente: "
      cod_idioma_correto = gets.chomp
      print "Digite o código do idioma para tradução: "
      cod_idioma_traducao = gets.chomp
      puts "Traduzindo... Texto: '#{@texto}' de '#{cod_idioma_correto}' para '#{cod_idioma_traducao}'"
      sleep(3)
      puts "Tradução: "
      resultado = consulta(cod_idioma_correto, cod_idioma_traducao)
      puts resultado
      gravar(@texto, resultado)
    else # USUÁRIO ESCREVE ALGO DIFERENTE 'S'OU 'N'
      puts "Desculpa, '#{selecao}' não corresponde ao que foi perguntado!"
      exit
    end
  end

  def consulta(cod1, cod2) # CONSULTA A TRADUÇÃO DO TEXTO
    response = RestClient.get @url_consulta, {
			params: {
				key: @key,
				text: @texto,
				lang: "#{cod1}-#{cod2}",
      }
    }
    JSON.parse(response)['text']
  end

  def detectar # TENTA DETECTAR O IDIOMA DO TEXTO PARA TRADUÇÃO
    response = RestClient.get @url_detecta, {
      params: {
        key: @key,
        text: @texto,
      }
    }
    return JSON.parse(response)['lang']
  end

  def listar_idioma # GERA UMA LISTA DE IDIOMAS DISPONIVEIS
    response = RestClient.get @url_listas, {
      params: {
        key: @key,
        ui: 'pt',
      }
    }

    JSON.parse(response)['langs'].each do |k, v|
      if k.length == 2
        k = " #{k}"
      end
      puts "Cód.: #{k} - Idioma: #{v}"
    end
  end

  def gravar(texto_o, texto_t) # GRAVA EM ARQUIVO TXT
    #gravacao dd-mm-yyyy_H:m.txt
    time = Time.new
    file_name = time.strftime('%d-%m-%Y') + '_' + time.strftime('%H:%M') + '.txt'
    File.open(file_name.to_s, 'a') do |l|
      l.puts("Texto Original: #{texto_o}")
      l.puts("Tradução: #{texto_t}")
    end
  end
end

Traduzir.new
